/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function home () {

    // ` this is a "back tick". Use it to define multi-line strings in JavaScript.
    var content = `
      <div id="home">

                <div class="row">
                    <div class='column column33'>
                        <img src='pics/blockParty1.jpg' alt='People at a party'>
                    </div>
                    <div class='column column66'>

                        <strong>Welcome </strong> to the Strathmore Road official Block Party website. Strathmore Road is a fun and lively street near the heart of 
                        Havertown. There are 4 block parties a year, 1 in the spring, 1 in the summer and 2 in the fall. Our block parties are 
                        a spectular way of getting to know lots of neighbors very quickly. I got some inspiration from this <a href="https://philadelphia.dinerenblanc.com/" target="_blank" style="text-decoration:none;">
                            concept</a>. So sign up and let the fun begin.
                    </div>
                </div>

                <div class="row">
                    <div class='column column66'>
                        <strong>Food</strong> Food that will always be at every party will include Dan's slow roasted firehouse chickens, hotdogs, hamburgers. 
                        The chicken goes fast so make sure you get there early. We will need as many grills as people can bring.
                        Anyone can bring salads, desserts, or casseroles, the list is endless.

                    </div>
                    <div class='column column33'>
                        <img src='pics/blockParty2.jpg' alt='Food'>
                    </div>
                </div>

                <div class="row">
                    <div class='column column33'>
                        <img src='pics/blockParty3.jpg' alt='Drinks'>
                    </div>
                    <div class='column column66'>
                        <strong>Amenities</strong> that will be provided are tables, tents, and chairs. A bouncy house will be included as a distraction for the children.
                        A keg of miller light will be provided as well. We encourage anyone to bring their own beer or wine or even a festive cocktail.
                    </div>
                </div>
            </div>
    `;
    
    var ele = document.createElement("div");
    ele.innerHTML = content;
    return ele; 
}
