/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function users() {
    var usersDOM = document.createElement("div");

    ajax("json/users.json", callBack1, usersDOM);

    //usersDOM.innerHTML = "hello"; used to check link


    function callBack1(myObj) {
//    var myObj =  document.createElement("div");
//         myObj.name = "frank";
//         myObj.last = "petrillo";
//         console.log(myObj.last);
        //do some playing with images for loop
        console.log(myObj);
//        function formatCurrency(num) {
//            var myNum = Number(num);
//            return myNum.toLocaleString("en-US", {style: "currency", currency: "USD", minimumFractionDigits: 2});
//        }


        // modify properties (image and price) of the array of objects so it will look 
        // better on the page.
        for (var i = 0; i < myObj.length; i++) {
            myObj[i].image = "<img  src='" + myObj[i].image + "' style='width:10rem'>";
            //myObj[i].membershipFee = formatCurrency(myObj[i].membershipFee);
        }


        var users1 = MakeClickSort({
            list: myObj,
            sortOrderPropName: "webUserId",
            header: "Users"
        }); //might need to pass title as well
        users1.classList.add("clickSort");
        usersDOM.appendChild(users1);

    }
    ;

    return usersDOM;
}

//var sortOrderPropName = params.sortOrderPropName || params.list[0]; //this is standard but extra checking is above
//    var sortIcon = params.sortIcon || "icons/sortUpDown16.png";
//    var header = params.header || "User List";
