function MakeSlideShow(params) {

    //create DOM object to hold slideshow picture
    var ssObj = document.createElement("div");
    console.log(params);


    //check if properties 'image' and 'caption' exist
    //not sure about appendChild
    //return is supposed close program
    //might need to nest the rest of function inside the if
    if (!params.objList || !params.objList[0]) {
       alert("Must provide an object with at least one property of ");

        return;
    }

    //passes parameter object into data members
    //If any are not passed then defaults are set
    ssObj.name = params.name || "unknown slideshow";

    //i think is very wrong, but it worked before
//    var myStyle = params.myStyle || "";
//
//    if (myStyle.length > 0) {
//        ssObj.classList.add(myStyle);
//    }

console.log(params.objList[0].make);

    //create element for slideshow name
    var slideShowName = document.createElement("h1");
    slideShowName.innerHTML = ssObj.name;
    ssObj.appendChild(slideShowName);

    //create another div because img is not a block element and put it on page
    var imageHolder = document.createElement("div");
    ssObj.appendChild(imageHolder);

    //create img to hold pic and put it on page
    var myImage = document.createElement("img");
    imageHolder.append(myImage);
    
    //create element for caption
    var slideShowCaption = document.createElement("h3");
    slideShowCaption.innerHTML = params.caption;
    console.log(params.objList.caption);
    console.log("65");
    ssObj.appendChild(slideShowCaption);


    //add back button and put it on page
    var backButton = document.createElement("button");
    backButton.innerHTML = " &lt; ";
    ssObj.appendChild(backButton);

    //add forward button and put it on page
    var fwdButton = document.createElement("button");
    fwdButton.innerHTML = " &gt; ";
    ssObj.appendChild(fwdButton);

    //private variable to keep track of where we are in slideshow
    var picNum = 0;

    //kind of like display here
    setPic();

    function setPic() {
        console.log("picNum is " + picNum);

        myImage.src = params.objList[picNum].image;
        console.log(myImage.src);
    }

    // Advance to next image in the picture list
    function nextPic() {

        if (picNum < params.objList.length - 1) {
            picNum++;
        }
        setPic();
    }

    // Go to the previous image in the picture list
    function prevPic() {

        if (picNum > 0) {
            picNum--;
        }
        setPic();

    }

    // add next and previous funcionality to next and previous buttons

    backButton.onclick = prevPic;
    fwdButton.onclick = nextPic;

    ssObj.setPicNum = function (newNum) {
        if ((newNum >= 0) && (newNum < ssObj.length)) {
            picNum = newNum;
            // change the src attribute of the image element to the desired new image)				
            setPic();
        }
    };

    //maybe give it a color too
    ssObj.onmouseover = function () {
        myImage.style.border = "6px solid";
    };


    //set slideshow name
    ssObj.setName = function (newName) {
        ssObj.name = newName;
        slideShowName.innerHTML = ssObj.name;
    };
    console.log(ssObj);
    return ssObj;
}


