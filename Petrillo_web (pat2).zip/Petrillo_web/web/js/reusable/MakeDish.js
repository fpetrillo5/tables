/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
"use strict";

function MakeDish(params) {
    // this is the div where all the properties will be
    var dishObj = document.createElement("div");

    //passes parameter object into data members
    //If any are not passed then defaults are set
    var name = params.name || "unknown";

    var cost = params.cost || 0;

    dishObj.description = params.description || "No Description";

    dishObj.pic = params.pic || "pics/blockParty5.jpg";

    //mutators for data members
    dishObj.setDescription = function (newDescription) {
        dishObj.description = newDescription;
        display();
    };

    //validates cost is positive
    dishObj.setCost = function (newCost) {
        if (newCost > 0) {
            cost = newCost;
            display();
        }
    };

    dishObj.setName = function (newName) {
        name = newName;
        display();
    };

    dishObj.setPic = function (newPic) {
        dishObj.pic = newPic;
        display();
    };

    //private function that can only be called in MakeDish
    var display = function () {
        dishObj.innerHTML = "Dish Name: " + name + "<br/> Dish Description: " + dishObj.description +
                "<br/>  Dish Cost: " + formatCurrency(cost) +
                "<br/> <img src='" + dishObj.pic + "'>";
    };

    // I bet this causes me problems
    function formatCurrency(num) {//change to format salary
        return num.toLocaleString("en-US", {style: "currency", currency: "USD", minimumFractionDigits: 2});
    }

    //changes cost amount, goes with the mouseover
    dishObj.changeCost = function (changeCost) {
        cost = cost * (1 + changeCost);
        display(); // show updated price on the page. private call
    };

    // when user clicks on div associated with this object
    dishObj.onmouseover = function () {
        console.log("will decrease price of your car object by 5%");//check
        dishObj.changeCost(0.05); // reduce price by 5%
    };

    //shows initially
    display();

    //sends object to twoDishes
    return dishObj;

}
