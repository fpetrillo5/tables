/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function users() {
    var usersDOM = document.createElement("div");
    
    ajax(json/users.json, callBack1, usersDOM);
    
    //usersDOM.innerHTML = "hello"; used to check link
    
    function callBack1(myObj){
//    var myObj =  document.createElement("div");
//         myObj.name = "frank";
//         myObj.last = "petrillo";
//         console.log(myObj.last);
        //do some playing with images for loop
        
        var users1 = MakeClickSort(myObj); //might need to pass title as well
        users1.classList.add("clickSort");
        usersDOM.appendChild(users1);
        
    };
    
    return usersDOM;
}


