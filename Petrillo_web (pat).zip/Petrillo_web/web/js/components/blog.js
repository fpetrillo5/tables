/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function blog() {

// ` this is a "back tick". Use it to define multi-line strings in JavaScript.
var content = ` 
      <div id="blog"> 

                <h3>Database Table Proposal</h3>
                <p> My proposal database table will be a table named ITEMS_CONTRIBUTED. This table will allow the user to list the items they plan 
                    on bringing to the block party. 
                </p>
                <ul>
                    <li>items_contributed_id
                        <ul>
                            <li>This will be an auto-incremented id primary key.</li>
                        </ul>
                    </li>
                    <li>description_items
                        <ul>
                            <li>This will allow user to let the organizer know what they are bringing.</li>
                        </ul>
                    </li>
                    <li>cost_items
                        <ul>
                            <li>An estimation of cost of items bringing to party.</li>
                        </ul>
                    </li>
                    <li>amount_guests
                        <ul>
                            <li>How many people are you bringing, including yourself.</li>
                        </ul>
                    </li>
                    <li>date_party
                        <ul>
                            <li>The date of the party you will be attending next.</li>
                        </ul>
                    </li>
                    <li>pk_web_user
                        <ul>
                            <li>This will be the foreign key connecting to the WEB_USER table.</li>
                        </ul>
                    </li>
                </ul>

                <h3>Experience</h3>
                <p>
                    My experience with web design is pretty limited. I understand the basic concepts of HTML and CSS but 
                    putting them into practice is something I have never really done much of. I have updated Wordpress sites at work
                    but that really was more data entry than anything. I have expereince using Postman and SoapUI when it comes to testing APIs
                    but again i have never written an API. Overall I dont have much experience but I dont panic when I have errors like I normally would
                    when Im doing something new. 
                </p>

                <h3>Blog</h3>
                 <h4>Homework 1<h4>
                <p>
                    The hardest part was coming up with a topic. I went through a couple different ideas, but none made sense when external
                    users would have a role in using the web site. The layout was obviously annoying but I expected it was going to be going in.
                    There was a couple last minute issues that popped up at the end. One was how the colors showed on different monitors. 
                    Most everything was new to me so it took a lot longer than I expected but nothing was overly complicated. I appreciated 
                    that in the lab last week we already did a submission of a web page. To be honest, that was probably the most complicated
                    part but there was plenty of documentation on the issue. 
                </p>
                <h4>Homework 2<h4>
                <p>
                    When I first looked at this homework initially, the things I thought would be hard turned out to be easy 
                    and the things I thought would be easy turned out to be the most difficult. The routing was intimidiating at first but
                    after watching the lecture it wasnt bad at all. I am glad I understood the routing before I started because I would
                    still be trying to copy and paste wildly. The dropdown, transition, and routing were basically given after comprehending it. I kept
                    waiting for a trap but none materialized (hopefully). The only thing we had to do was close the dropdown by clicking on the window.
                    I banged around for 30 minutes before googling it. Fortunately I found a W3schools version that worked perfectly. I enjoyed the homework
                    because I was able to learn the routing without having to hack away at a solution for days. I really do appreciate the thorough instructions
                    in these homeworks because with some programming projects the hardest part is trying to figure out what the teacher wants.
                </p>
    
                <h4>Homework 3<h4>
                <p>
                   Things got out of control fast. I struggled with the simple toggle function (at least that works), and pretty much everything else.
                    The page is not styled because everything I touch breaks. The dropdown needs to be in a provider style, which 
                    it is not in currently. The buttons dont work, I didnt pass in styling, hence the out of control pictures. 
                    I know this is not good, but on the bright side there are no errors. I have a much better idea of what provider 
                    styling coding concept means. But I will fix the issues and learn from them.
                </p>
    
                 <h4>Homework 4<h4>
                <p>
                   Looking back my issues with past homework trivial. This homework gave me trouble but I didnt until it was too late.
                   I have a bad feeling I have a major issue with the slideShow object. I get undefined
                   for the caption. Im not really sure why that is. Surprisingly I found the AJAX not difficult to understand. 
                   But my main issue is with the object, which Im pretty sure is a large part of the grade.
                </p>
            </div>
    `;
        var ele = document.createElement("div");
        ele.innerHTML = content;
        return ele;
        }
