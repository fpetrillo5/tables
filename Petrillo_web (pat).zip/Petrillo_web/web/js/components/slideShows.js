"use strict";

function slideShows (){
    
    var slideShowDOM = document.createElement("div");
    
    ajax("json/cars.json",callBack1, slideShowDOM);
    //after ajax puts everything inside of process data
    //loops through ajax and stores into myObjArray
    function callBack1 (myObj){
        console.log(myObj);
        for(var i =0; i < myObj.length; i++){
            
            //myObj[i].image = myObj[i].image;
            console.log("image " + i + " " + myObj[i].image);
            
            myObj[i].caption = myObj[i].make;
            console.log("caption " + i + " " + myObj[i].caption);
        }
        
      
        console.log(myObj[2].caption);
        
       
        var ss1 = MakeSlideShow({objList:myObj});
        ss1.classList.add("slideShow");
        console.log(ss1);
        console.log("45");
        slideShowDOM.appendChild(ss1);
        ss1.setName("Cars");
      
       
       
    };
    
    ajax("json/cats.json",callBack2, slideShowDOM);
    //after ajax puts everything inside of process data
    //loops through ajax and stores into myObjArray
    function callBack2 (myObj){
        console.log(myObj);
        for(var i =0; i < myObj.length; i++){
            
            //myObj[i].image = myObj[i].image;
            console.log("image " + i + " " + myObj[i].image);
            
            myObj[i].caption = myObj[i].make;
            console.log("caption " + i + " " + myObj[i].caption);
        }
        
      
        console.log(myObj);
        
       
        var ss2 = MakeSlideShow({objList:myObj});
        ss2.classList.add("slideShow");
        console.log(myObj[0].caption);
        console.log("45");
        slideShowDOM.appendChild(ss2);
        ss2.setName("Cats");
      
       
       
    };
    
    return slideShowDOM;
  
}

